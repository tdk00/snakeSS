package lesson14.snake.client;

import java.awt.*;
import java.io.Serializable;

public class BoardVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String flight_id;
    private int[][] maze7;
    private Point[] headAndTail;




    public int[][] getMaze7() {
        return maze7;
    }

    public void setMaze7(int[][] maze7) {
        this.maze7 = maze7;
    }

    public Point[] getHeadAndTail() {
        return headAndTail;
    }

    public void setHeadAndTail(Point[] headAndTail) {
        this.headAndTail = headAndTail;

    }
}