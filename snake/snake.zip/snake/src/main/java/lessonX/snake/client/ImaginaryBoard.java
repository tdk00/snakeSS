package lesson14.snake.client;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ImaginaryBoard {
    public static BoardVO pathExists(int[][] Maze, List<Point> path, ArrayList<List<Integer>> newSnake){
        int[][] Maze2 = {
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
        Point tail = null;
        Point head = null;
        for (int i1=0; i1<Maze.length;i1++) {
            for(int j1=0; j1<Maze[i1].length;j1++){
                  Maze2[i1][j1] = Maze[i1][j1];
            }
        }

        if(path.size()-1>newSnake.size()){
            Maze2 = removeSnakeFromMaze(Maze2,newSnake);
            for (int i=1;i<=newSnake.size()+1;i++) {
                Maze2[(int) path.get(path.size()-i).getY()][(int) path.get(path.size()-i).getX()] = 1;
                if(i==newSnake.size()+1){
                    tail = new Point ((int) path.get(path.size()-i).getX()+1,13-(int) path.get(path.size()-i).getY());
                    head = new Point (path.get(path.size()-1));
                }
            }
        }
        else
        {
            for (int i=1;i<=path.size();i++) {
                Maze2[(int) path.get(path.size()-i).getY()][(int) path.get(path.size()-i).getX()] = 1;

                    tail = new Point ((newSnake.get(newSnake.size()-(path.size()-1)).get(0)),(newSnake.get(newSnake.size()-(path.size()-1)).get(1)));
                    head = new Point (path.get(path.size()-1));

                if(i==path.size() || i==path.size()-1) continue;
                Maze2[13-newSnake.get(newSnake.size()-i).get(1)][newSnake.get(newSnake.size()-i).get(0)-1] = 0;

            }
        }
        Point[] a = {head,tail};
        BoardVO vo = new BoardVO();
        vo.setHeadAndTail(a);
        vo.setMaze7(Maze2);
        return vo;
    }


    public static int[][] removeSnakeFromMaze(int[][] maze, ArrayList<List<Integer>> newSnake){
        for (List<Integer> ch: newSnake) {
            maze[13-ch.get(1)][ch.get(0)-1] = 0;
        }
        return maze;
    }
}
